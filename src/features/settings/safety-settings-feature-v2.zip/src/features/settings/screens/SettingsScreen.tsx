import React, { useMemo, useRef, useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { DEFAULT_SETTINGS, ALERT_LOG_KEY, LOCATION_HISTORY_KEY } from "../defaults";
import { useSettings } from "../hooks/useSettings";
import { useShakeDetector } from "../hooks/useShakeDetector";
import type { DecoyType, EmergencyContact, GestureType, VoiceTone, VoiceType } from "../types";
import { readJSON, writeJSON } from "../storage";
import { applyTemplate, clamp, insertAt, TEMPLATE_VARS } from "../utils/format";
import { confirm, info } from "../components/ConfirmDialog";
import { ContactEditorModal } from "../components/ContactEditorModal";
import { OptionPicker } from "../components/OptionPicker";
import { Row } from "../components/Row";
import { SectionCard } from "../components/SectionCard";
import { DecoyModal } from "../components/DecoyModal";

function loadSMS(): any | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("expo-sms");
    return mod;
  } catch {
    return null;
  }
}

function loadSpeech(): any | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("expo-speech");
    return mod;
  } catch {
    return null;
  }
}

function loadFileSystem(): any | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("expo-file-system");
    return mod;
  } catch {
    return null;
  }
}

function loadSharing(): any | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("expo-sharing");
    return mod;
  } catch {
    return null;
  }
}

function loadHaptics(): any | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("expo-haptics");
    return mod;
  } catch {
    return null;
  }
}

function loadSlider(): any | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("@react-native-community/slider");
    const Slider = mod?.default ?? mod;
    return Slider;
  } catch {
    return null;
  }
}

export function SettingsScreen() {
  const { loading, settings, update, contacts, contactActions, privacyActions, gestureHelpers } = useSettings();

  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<EmergencyContact | undefined>(undefined);

  const [decoyOpen, setDecoyOpen] = useState(false);

  const SMS = useMemo(() => loadSMS(), []);
  const Speech = useMemo(() => loadSpeech(), []);
  const FileSystem = useMemo(() => loadFileSystem(), []);
  const Sharing = useMemo(() => loadSharing(), []);
  const Haptics = useMemo(() => loadHaptics(), []);
  const Slider = useMemo(() => loadSlider(), []);

  // Shake detection feedback
  const [shakeCount, setShakeCount] = useState(0);
  const shake = useShakeDetector({
    enabled: settings.gesture.enabled && settings.gesture.type === "shake",
    sensitivity: settings.gesture.shakeSensitivity,
    onShake: () => {
      setShakeCount((c) => c + 1);
      if (!settings.gesture.practiceMode) {
        // In real app, this would trigger alerts. In settings, we keep it safe and informational.
        void info("Shake detected", "Shake gesture detected. Practice mode is OFF—ensure your alert pipeline is set up.");
      }
    },
  });

  const templatePreview = useMemo(() => {
    const vars = {
      NAME: "Jordan",
      LOCATION: "123 Main St, Indianapolis, IN",
      TIME: new Date().toLocaleString(),
    };
    return applyTemplate(settings.templates.defaultMessage, vars);
  }, [settings.templates.defaultMessage]);

  const voiceLabel = useMemo(() => `${capitalize(settings.voice.voiceType)} · ${capitalize(settings.voice.tone)}`, [settings.voice]);

  const [templateSelection, setTemplateSelection] = useState({ start: 0, end: 0 });
  const templateInputRef = useRef<TextInput | null>(null);

  const [customForId, setCustomForId] = useState<string | null>(null);
  const customContact = useMemo(() => contacts.find((c) => c.id === customForId) ?? null, [contacts, customForId]);

  if (loading) {
    return (
      <View style={[styles.safe, { justifyContent: "center", alignItems: "center" }]}>
        <Text style={{ fontWeight: "800" }}>Loading settings…</Text>
      </View>
    );
  }

  async function sendTestSMS(contact: EmergencyContact) {
    const vars = {
      NAME: "Me",
      LOCATION: "(location placeholder)",
      TIME: new Date().toLocaleString(),
    };
    const message = applyTemplate(contact.customMessage ?? settings.templates.defaultMessage, vars);

    // Try expo-sms first
    if (SMS?.isAvailableAsync && SMS?.sendSMSAsync) {
      try {
        const available = await SMS.isAvailableAsync();
        if (!available) {
          await openSmsFallback(contact.phone, message);
          return;
        }
        await SMS.sendSMSAsync([contact.phone], message);
        return;
      } catch (e: any) {
        await info("SMS failed", e?.message ?? "Unable to send SMS.");
        return;
      }
    }

    // Fallback: use sms: link
    await openSmsFallback(contact.phone, message);
  }

  async function openSmsFallback(phone: string, body: string) {
    const url = Platform.select({
      ios: `sms:${encodeURIComponent(phone)}&body=${encodeURIComponent(body)}`,
      android: `sms:${encodeURIComponent(phone)}?body=${encodeURIComponent(body)}`,
      default: `sms:${encodeURIComponent(phone)}`,
    })!;
    const can = await Linking.canOpenURL(url);
    if (!can) {
      await info("SMS unavailable", "Couldn't open the SMS app on this device.");
      return;
    }
    await Linking.openURL(url);
  }

  async function previewVoice() {
    const phrase =
      settings.voice.tone === "professional"
        ? "This is a safety check. Please stay calm. Help is being contacted."
        : settings.voice.tone === "casual"
        ? "Hey, just checking in—let's stay safe."
        : "I need help. Please respond as soon as you can.";
    if (Speech?.stop) Speech.stop();
    if (Speech?.speak) {
      try {
        Speech.speak(phrase, {
          rate: 1.0,
          pitch: settings.voice.voiceType === "female" ? 1.2 : settings.voice.voiceType === "male" ? 0.9 : 1.0,
          volume: clamp(settings.voice.volume, 0, 1),
        });
        return;
      } catch {}
    }
    await info("Preview unavailable", "Install expo-speech for voice preview, or wire in ElevenLabs playback.");
  }

  async function exportData() {
    const payload = {
      exportedAt: new Date().toISOString(),
      settings,
      locationHistory: (await readJSON<any>(LOCATION_HISTORY_KEY)) ?? [],
      alertLog: (await readJSON<any>(ALERT_LOG_KEY)) ?? [],
    };

    // If Expo FS + Sharing exist, share a JSON file. Otherwise, show a limited copy-to-clipboard alert.
    if (FileSystem?.writeAsStringAsync && Sharing?.shareAsync) {
      try {
        const path = FileSystem.cacheDirectory + "safetyapp-export.json";
        await FileSystem.writeAsStringAsync(path, JSON.stringify(payload, null, 2));
        await Sharing.shareAsync(path);
        return;
      } catch (e: any) {
        await info("Export failed", e?.message ?? "Unable to export.");
        return;
      }
    }

    Alert.alert("Export", "Install expo-file-system and expo-sharing to export a JSON file.");
  }

  async function clearLocationData() {
    const ok = await confirm("Clear location data?", "This will delete all stored location history and alert logs.");
    if (!ok) return;
    await privacyActions.clearAllLocationData();
    await info("Cleared", "All stored location data has been cleared.");
  }

  function insertVar(v: string) {
    const text = settings.templates.defaultMessage;
    const next = insertAt(text, v, templateSelection.start, templateSelection.end);
    update({ templates: { ...settings.templates, defaultMessage: next } });
    // Keep focus after insert
    setTimeout(() => templateInputRef.current?.focus(), 50);
  }

  const gestureTip = useMemo(() => {
    if (settings.gesture.type === "shake") return "Tip: Try short, firm shakes (like shaking a flashlight).";
    if (settings.gesture.type === "volume") return "Tip: Requires background key-event listener. Use when phone is pocketed.";
    return "Tip: Requires background key-event listener. Useful when screen is off.";
  }, [settings.gesture.type]);

  const gestureAvailableText = useMemo(() => {
    if (settings.gesture.type !== "shake") return "Real-time detection is available for shake only in this build.";
    if (!shake.available) return "Accelerometer not available (install expo-sensors).";
    return shake.active ? "Listening for shake…" : "Not listening";
  }, [settings.gesture.type, shake.available, shake.active]);

  const decoySubtitle = settings.decoy.enabled
    ? "Open a realistic screen to stay safe in public. Exit via secret gesture."
    : "Decoy screens are disabled.";

  return (
    <KeyboardAvoidingView style={styles.safe} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.h1}>Settings</Text>

        {/* Emergency Contacts */}
        <SectionCard
          title="Emergency Contacts"
          subtitle={`Add up to 5 contacts. Use “Test Alert” to send a safe SMS preview.`}
        >
          <Row
            label="Walking Mode auto-notify"
            description="When Walking Mode starts, automatically notify your emergency contacts (if enabled in the alert flow)."
            right={
              <SwitchLike
                value={settings.walkingModeAutoNotify}
                onChange={(v) => update({ walkingModeAutoNotify: v })}
              />
            }
          />

          <View style={{ gap: 10 }}>
            {contacts.length === 0 ? (
              <Text style={styles.muted}>No contacts yet.</Text>
            ) : null}

            {contacts.map((c) => (
              <View key={c.id} style={styles.contactCard}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.contactName}>{c.name}</Text>
                  <Text style={styles.contactMeta}>
                    {c.relationship ? `${c.relationship} · ` : ""}
                    {c.phone}
                  </Text>
                </View>
                <Pressable
                  style={({ pressed }) => [styles.smallBtn, pressed ? { opacity: 0.7 } : null]}
                  onPress={() => {
                    setEditing(c);
                    setEditorOpen(true);
                  }}
                >
                  <Text style={styles.smallBtnText}>Edit</Text>
                </Pressable>
                <Pressable
                  style={({ pressed }) => [styles.smallBtn, pressed ? { opacity: 0.7 } : null]}
                  onPress={async () => {
                    const ok = await confirm("Delete contact?", `Remove ${c.name} from emergency contacts?`, "Delete");
                    if (!ok) return;
                    contactActions.remove(c.id);
                  }}
                >
                  <Text style={[styles.smallBtnText, { color: "#B00020" }]}>Delete</Text>
                </Pressable>
              </View>
            ))}
          </View>

          <View style={{ flexDirection: "row", gap: 10 }}>
            <Pressable
              disabled={contacts.length >= 5}
              style={({ pressed }) => [styles.primaryBtn, contacts.length >= 5 ? { opacity: 0.5 } : null, pressed ? { opacity: 0.7 } : null]}
              onPress={() => {
                setEditing(undefined);
                setEditorOpen(true);
              }}
            >
              <Text style={styles.primaryText}>Add Contact</Text>
            </Pressable>

            <Pressable
              disabled={contacts.length === 0}
              style={({ pressed }) => [styles.secondaryBtn, contacts.length === 0 ? { opacity: 0.5 } : null, pressed ? { opacity: 0.7 } : null]}
              onPress={async () => {
                if (contacts.length === 0) return;
                // Quick test: pick first contact
                await sendTestSMS(contacts[0]);
              }}
            >
              <Text style={styles.secondaryText}>Test Alert (1st)</Text>
            </Pressable>
          </View>

          <Text style={styles.footnote}>
            {SMS ? "SMS: expo-sms detected." : "SMS: using device SMS app fallback."}
          </Text>
        </SectionCard>

        {/* Gesture Detection */}
        <SectionCard title="SafeSignal Gesture Detection" subtitle={gestureTip}>
          <Row
            label="Enable gesture trigger"
            right={<SwitchLike value={settings.gesture.enabled} onChange={(v) => update({ gesture: { ...settings.gesture, enabled: v } })} />}
          />

          <OptionPicker<GestureType>
            label="Gesture"
            value={settings.gesture.type}
            onChange={(v) => update({ gesture: { ...settings.gesture, type: v } })}
            options={[
              { value: "shake", label: "Shake (accelerometer)", description: "Works with phone in pocket. Real-time detection available." },
              { value: "volume", label: "Volume buttons", description: "Press volume up/down pattern. Needs key-event integration." },
              { value: "power", label: "Power button", description: "Press power multiple times. Needs key-event integration." },
            ]}
          />

          <Row
            label="Practice mode"
            description="Practice without triggering real alerts."
            right={
              <SwitchLike
                value={settings.gesture.practiceMode}
                onChange={(v) => update({ gesture: { ...settings.gesture, practiceMode: v } })}
              />
            }
          />

          {settings.gesture.type === "shake" ? (
            <>
              <Text style={styles.smallLabel}>Shake sensitivity</Text>
              {Slider ? (
                <View style={{ paddingHorizontal: 6 }}>
                  <Slider
                    minimumValue={0.5}
                    maximumValue={3.0}
                    value={settings.gesture.shakeSensitivity}
                    onValueChange={(v: number) => gestureHelpers.setShakeSensitivity(v)}
                  />
                </View>
              ) : (
                <Stepper
                  value={settings.gesture.shakeSensitivity}
                  onChange={(v) => gestureHelpers.setShakeSensitivity(v)}
                  step={0.1}
                  min={0.5}
                  max={3.0}
                />
              )}
            </>
          ) : null}

          <View style={styles.statusPill}>
            <Text style={styles.statusText}>{gestureAvailableText}</Text>
            {settings.gesture.type === "shake" ? (
              <Text style={styles.statusText}>Detected: {shakeCount}</Text>
            ) : null}
          </View>

          <Text style={styles.footnote}>
            {settings.gesture.type === "shake"
              ? "Haptics on detection if expo-haptics is installed."
              : "Volume/Power gestures are UI-ready; wire native listeners to trigger your alert flow."}
          </Text>
        </SectionCard>

        {/* Alert Templates */}
        <SectionCard title="Alert Message Templates" subtitle="Use variables: [LOCATION], [TIME], [NAME].">
          <Text style={styles.smallLabel}>Default emergency message</Text>
          <TextInput
            ref={(r) => (templateInputRef.current = r)}
            value={settings.templates.defaultMessage}
            onChangeText={(t) => update({ templates: { ...settings.templates, defaultMessage: t } })}
            onSelectionChange={(e) => setTemplateSelection(e.nativeEvent.selection)}
            multiline
            style={styles.textArea}
            placeholder="Enter your default emergency message…"
          />

          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
            {TEMPLATE_VARS.map((v) => (
              <Pressable key={v} style={({ pressed }) => [styles.tag, pressed ? { opacity: 0.7 } : null]} onPress={() => insertVar(v)}>
                <Text style={styles.tagText}>{v}</Text>
              </Pressable>
            ))}
          </View>

          <Text style={styles.smallLabel}>Live preview</Text>
          <View style={styles.preview}>
            <Text style={styles.previewText}>{templatePreview}</Text>
          </View>

          <Text style={styles.smallLabel}>Custom message per contact</Text>
          {contacts.length === 0 ? (
            <Text style={styles.muted}>Add an emergency contact to set a custom message.</Text>
          ) : (
            <>
              <OptionPicker<string>
                label="Contact"
                value={customForId ?? contacts[0].id}
                onChange={(v) => setCustomForId(v)}
                options={contacts.map((c) => ({
                  value: c.id,
                  label: c.name,
                  description: c.phone,
                }))}
              />

              {customContact ? (
                <>
                  <TextInput
                    value={customContact.customMessage ?? ""}
                    onChangeText={(t) => contactActions.setCustomMessage(customContact.id, t)}
                    multiline
                    style={styles.textArea}
                    placeholder="Leave empty to use default message."
                  />
                  <Pressable
                    style={({ pressed }) => [styles.secondaryBtn, pressed ? { opacity: 0.7 } : null]}
                    onPress={() => contactActions.setCustomMessage(customContact.id, undefined)}
                  >
                    <Text style={styles.secondaryText}>Clear custom message</Text>
                  </Pressable>
                </>
              ) : null}
            </>
          )}
        </SectionCard>

        {/* Voice Settings */}
        <SectionCard title="Voice Settings" subtitle="Preview uses expo-speech (optional). ElevenLabs integration ready.">
          <Row label="Current voice" value={voiceLabel} />

          <OptionPicker<VoiceType>
            label="Voice type"
            value={settings.voice.voiceType}
            onChange={(v) => update({ voice: { ...settings.voice, voiceType: v } })}
            options={[
              { value: "female", label: "Female" },
              { value: "male", label: "Male" },
              { value: "neutral", label: "Neutral" },
            ]}
          />

          <OptionPicker<VoiceTone>
            label="Tone"
            value={settings.voice.tone}
            onChange={(v) => update({ voice: { ...settings.voice, tone: v } })}
            options={[
              { value: "casual", label: "Casual", description: "Friendly and non-alarming." },
              { value: "concerned", label: "Concerned", description: "Urgent but calm." },
              { value: "professional", label: "Professional", description: "Clear, directive, official." },
            ]}
          />

          <Text style={styles.smallLabel}>Volume</Text>
          {Slider ? (
            <View style={{ paddingHorizontal: 6 }}>
              <Slider
                minimumValue={0}
                maximumValue={1}
                value={settings.voice.volume}
                onValueChange={(v: number) => update({ voice: { ...settings.voice, volume: clamp(v, 0, 1) } })}
              />
            </View>
          ) : (
            <Stepper
              value={settings.voice.volume}
              onChange={(v) => update({ voice: { ...settings.voice, volume: clamp(v, 0, 1) } })}
              step={0.05}
              min={0}
              max={1}
            />
          )}

          <Pressable style={({ pressed }) => [styles.primaryBtn, pressed ? { opacity: 0.7 } : null]} onPress={previewVoice}>
            <Text style={styles.primaryText}>Preview voice</Text>
          </Pressable>

          <Text style={styles.footnote}>{Speech ? "Voice preview: expo-speech detected." : "Voice preview: install expo-speech or wire ElevenLabs audio playback."}</Text>
        </SectionCard>

        {/* Decoy Screens */}
        <SectionCard title="Decoy Screens" subtitle={decoySubtitle}>
          <Row
            label="Enable decoy screens"
            right={<SwitchLike value={settings.decoy.enabled} onChange={(v) => update({ decoy: { ...settings.decoy, enabled: v } })} />}
          />

          <OptionPicker<DecoyType>
            label="Decoy type"
            value={settings.decoy.selected}
            disabled={!settings.decoy.enabled}
            onChange={(v) => update({ decoy: { ...settings.decoy, selected: v } })}
            options={[
              { value: "calculator", label: "Calculator" },
              { value: "weather", label: "Weather" },
              { value: "notes", label: "Notes" },
              { value: "browser", label: "Browser" },
            ]}
          />

          <Row
            label="Practice mode"
            description="Practice without impacting your normal flow."
            disabled={!settings.decoy.enabled}
            right={
              <SwitchLike
                value={settings.decoy.practiceMode}
                onChange={(v) => update({ decoy: { ...settings.decoy, practiceMode: v } })}
                disabled={!settings.decoy.enabled}
              />
            }
          />

          <Pressable
            disabled={!settings.decoy.enabled}
            style={({ pressed }) => [styles.primaryBtn, !settings.decoy.enabled ? { opacity: 0.5 } : null, pressed ? { opacity: 0.7 } : null]}
            onPress={() => setDecoyOpen(true)}
          >
            <Text style={styles.primaryText}>Open decoy (practice)</Text>
          </Pressable>

          <Text style={styles.footnote}>Secret exit: tap the top-left corner 3x.</Text>
        </SectionCard>

        {/* Privacy */}
        <SectionCard title="Privacy Controls" subtitle="Your data stays on-device by default.">
          <OptionPicker<"24h" | "7d" | "never">
            label="Auto-delete policy"
            value={settings.privacy.autoDelete}
            onChange={(v) => update({ privacy: { ...settings.privacy, autoDelete: v } })}
            options={[
              { value: "24h", label: "Delete after 24 hours" },
              { value: "7d", label: "Delete after 7 days" },
              { value: "never", label: "Never auto-delete" },
            ]}
          />

          <OptionPicker<"always" | "duringAlerts" | "never">
            label="Location sharing"
            value={settings.privacy.locationSharing}
            onChange={(v) => update({ privacy: { ...settings.privacy, locationSharing: v } })}
            options={[
              { value: "always", label: "Always" },
              { value: "duringAlerts", label: "Only during alerts" },
              { value: "never", label: "Never" },
            ]}
          />

          <Pressable style={({ pressed }) => [styles.secondaryBtn, pressed ? { opacity: 0.7 } : null]} onPress={exportData}>
            <Text style={styles.secondaryText}>Export my data (JSON)</Text>
          </Pressable>

          <Pressable style={({ pressed }) => [styles.dangerBtn, pressed ? { opacity: 0.7 } : null]} onPress={clearLocationData}>
            <Text style={styles.dangerText}>Clear all location data</Text>
          </Pressable>

          <View style={styles.privacyBox}>
            <Text style={styles.privacyTitle}>Compliance</Text>
            <Text style={styles.privacyText}>
              GDPR/CCPA: This screen provides data export and deletion controls. Ensure your privacy policy explains what is stored, for how long,
              and how users can delete data.
            </Text>
          </View>
        </SectionCard>

        <View style={{ height: 10 }} />
      </ScrollView>

      {/* Modals */}
      <ContactEditorModal
        visible={editorOpen}
        initial={editing}
        onClose={() => setEditorOpen(false)}
        onSave={(c) => contactActions.add(c)}
        onUpdate={(c) => contactActions.update(c)}
      />

      <DecoyModal visible={decoyOpen} type={settings.decoy.selected} onRequestClose={() => setDecoyOpen(false)} />
    </KeyboardAvoidingView>
  );
}

function capitalize(s: string) {
  return s ? s[0].toUpperCase() + s.slice(1) : s;
}

function SwitchLike(props: { value: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <Pressable
      disabled={props.disabled}
      onPress={() => props.onChange(!props.value)}
      style={({ pressed }) => [
        styles.switch,
        props.value ? styles.switchOn : styles.switchOff,
        props.disabled ? { opacity: 0.5 } : null,
        pressed ? { opacity: 0.7 } : null,
      ]}
    >
      <View style={[styles.knob, props.value ? { marginLeft: 18 } : { marginLeft: 2 }]} />
    </Pressable>
  );
}

function Stepper(props: { value: number; onChange: (v: number) => void; step: number; min: number; max: number }) {
  const value = Number.isFinite(props.value) ? props.value : 0;
  return (
    <View style={styles.stepper}>
      <Pressable
        style={({ pressed }) => [styles.stepBtn, pressed ? { opacity: 0.7 } : null]}
        onPress={() => props.onChange(clamp(round(value - props.step), props.min, props.max))}
      >
        <Text style={styles.stepText}>−</Text>
      </Pressable>
      <Text style={styles.stepValue}>{round(value).toFixed(props.step < 0.1 ? 2 : props.step < 1 ? 1 : 0)}</Text>
      <Pressable
        style={({ pressed }) => [styles.stepBtn, pressed ? { opacity: 0.7 } : null]}
        onPress={() => props.onChange(clamp(round(value + props.step), props.min, props.max))}
      >
        <Text style={styles.stepText}>+</Text>
      </Pressable>
    </View>
  );
}

function round(n: number) {
  return Math.round(n * 100) / 100;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F6F6F8" },
  content: { padding: 14, paddingBottom: 28 },
  h1: { fontSize: 28, fontWeight: "900", marginBottom: 10 },

  muted: { color: "rgba(0,0,0,0.55)", fontSize: 13 },

  contactCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 10,
    borderRadius: 14,
    backgroundColor: "rgba(0,0,0,0.03)",
  },
  contactName: { fontSize: 14, fontWeight: "900" },
  contactMeta: { marginTop: 2, fontSize: 12, color: "rgba(0,0,0,0.6)" },

  smallBtn: {
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 12,
    backgroundColor: "rgba(0,0,0,0.06)",
  },
  smallBtnText: { fontSize: 12, fontWeight: "800" },

  primaryBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 14,
    backgroundColor: "rgba(0,0,0,0.88)",
    alignItems: "center",
  },
  primaryText: { color: "#fff", fontSize: 13, fontWeight: "900" },

  secondaryBtn: {
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: "rgba(0,0,0,0.08)",
    alignItems: "center",
  },
  secondaryText: { fontSize: 13, fontWeight: "900" },

  dangerBtn: {
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: "rgba(176,0,32,0.12)",
    alignItems: "center",
  },
  dangerText: { fontSize: 13, fontWeight: "900", color: "#B00020" },

  smallLabel: { fontSize: 12, fontWeight: "800", color: "rgba(0,0,0,0.65)" },

  textArea: {
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(0,0,0,0.18)",
    paddingHorizontal: 12,
    paddingVertical: 10,
    minHeight: 92,
    backgroundColor: "#fff",
    fontSize: 14,
  },

  tag: {
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 999,
    backgroundColor: "rgba(0,0,0,0.07)",
  },
  tagText: { fontWeight: "800", fontSize: 12 },

  preview: {
    backgroundColor: "rgba(0,0,0,0.03)",
    borderRadius: 14,
    padding: 12,
  },
  previewText: { fontSize: 13, color: "rgba(0,0,0,0.8)", lineHeight: 18 },

  statusPill: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: "rgba(0,0,0,0.05)",
  },
  statusText: { fontSize: 12, fontWeight: "800", color: "rgba(0,0,0,0.75)" },

  footnote: { fontSize: 12, color: "rgba(0,0,0,0.55)" },

  switch: {
    width: 42,
    height: 24,
    borderRadius: 999,
    padding: 2,
    justifyContent: "center",
  },
  switchOn: { backgroundColor: "rgba(0,0,0,0.85)" },
  switchOff: { backgroundColor: "rgba(0,0,0,0.25)" },
  knob: { width: 20, height: 20, borderRadius: 999, backgroundColor: "#fff" },

  stepper: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: "rgba(0,0,0,0.04)",
  },
  stepBtn: { width: 38, height: 32, borderRadius: 10, backgroundColor: "rgba(0,0,0,0.08)", alignItems: "center", justifyContent: "center" },
  stepText: { fontSize: 18, fontWeight: "900" },
  stepValue: { fontSize: 12, fontWeight: "900", color: "rgba(0,0,0,0.7)" },

  privacyBox: {
    padding: 12,
    borderRadius: 14,
    backgroundColor: "rgba(0,0,0,0.03)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(0,0,0,0.10)",
  },
  privacyTitle: { fontSize: 13, fontWeight: "900" },
  privacyText: { marginTop: 6, fontSize: 12, color: "rgba(0,0,0,0.65)", lineHeight: 16 },
});
