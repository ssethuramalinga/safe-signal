export { SettingsScreen } from "./screens/SettingsScreen";
export type { AppSettings, EmergencyContact, DecoyType, GestureType, VoiceTone, VoiceType } from "./types";
export * from "./navigation";
