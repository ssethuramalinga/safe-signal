import React from "react";
import { Ionicons } from "@expo/vector-icons";
import { SettingsScreen } from "./screens/SettingsScreen";

/**
 * React Navigation helpers.
 *
 * How to use (Bottom Tabs):
 *   <Tab.Screen
 *     name={SETTINGS_ROUTE_NAME}
 *     component={SettingsScreen}
 *     options={settingsTabOptions}
 *   />
 */
export const SETTINGS_ROUTE_NAME = "Settings";

// Minimal options object that works with @react-navigation/bottom-tabs
export const settingsTabOptions: any = {
  title: "Settings",
  tabBarLabel: "Settings",
  tabBarIcon: ({ color, size }: any) => (
    <Ionicons name="settings-outline" size={size ?? 22} color={color} />
  ),
};

// If you use a Stack navigator
export const settingsStackOptions: any = {
  title: "Settings",
  headerTitle: "Settings",
};

// Convenience export if you like importing a single screen reference
export const SettingsTabScreen = SettingsScreen;
