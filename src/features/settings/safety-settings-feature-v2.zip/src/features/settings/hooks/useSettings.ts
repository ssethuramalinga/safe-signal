import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { DEFAULT_SETTINGS, SETTINGS_STORAGE_KEY, LOCATION_HISTORY_KEY, ALERT_LOG_KEY } from "../defaults";
import type { AppSettings, EmergencyContact } from "../types";
import { readJSON, removeKey, writeJSON } from "../storage";
import { clamp } from "../utils/format";

function mergeSettings(base: AppSettings, incoming: Partial<AppSettings> | null): AppSettings {
  if (!incoming) return base;
  // Shallow merge with nested merges to preserve new defaults
  return {
    ...base,
    ...incoming,
    emergencyContacts: Array.isArray(incoming.emergencyContacts)
      ? incoming.emergencyContacts
      : base.emergencyContacts,
    gesture: { ...base.gesture, ...(incoming.gesture ?? {}) },
    templates: { ...base.templates, ...(incoming.templates ?? {}) },
    voice: { ...base.voice, ...(incoming.voice ?? {}) },
    decoy: { ...base.decoy, ...(incoming.decoy ?? {}) },
    privacy: { ...base.privacy, ...(incoming.privacy ?? {}) },
  };
}

function uuid(): string {
  // Reasonable unique id without extra deps
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function useSettings() {
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const savingRef = useRef(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      const stored = await readJSON<Partial<AppSettings>>(SETTINGS_STORAGE_KEY);
      if (!alive) return;
      setSettings(mergeSettings(DEFAULT_SETTINGS, stored));
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, []);

  const persist = useCallback(async (next: AppSettings) => {
    // Avoid concurrent writes; latest state will be saved by next call.
    if (savingRef.current) return;
    savingRef.current = true;
    try {
      await writeJSON(SETTINGS_STORAGE_KEY, next);
    } finally {
      savingRef.current = false;
    }
  }, []);

  const update = useCallback(
    async (patch: Partial<AppSettings> | ((prev: AppSettings) => AppSettings)) => {
      setSettings((prev) => {
        const next = typeof patch === "function" ? patch(prev) : mergeSettings(prev, patch);
        void persist(next);
        return next;
      });
    },
    [persist]
  );

  const contacts = settings.emergencyContacts;

  const contactActions = useMemo(
    () => ({
      add(contact: Omit<EmergencyContact, "id">) {
        update((prev) => {
          const nextContact: EmergencyContact = { ...contact, id: uuid() };
          const next = {
            ...prev,
            emergencyContacts: [...prev.emergencyContacts, nextContact].slice(0, 5),
          };
          return next;
        });
      },
      update(contact: EmergencyContact) {
        update((prev) => ({
          ...prev,
          emergencyContacts: prev.emergencyContacts.map((c) => (c.id === contact.id ? contact : c)),
        }));
      },
      remove(id: string) {
        update((prev) => ({
          ...prev,
          emergencyContacts: prev.emergencyContacts.filter((c) => c.id !== id),
        }));
      },
      setCustomMessage(contactId: string, customMessage: string | undefined) {
        update((prev) => ({
          ...prev,
          emergencyContacts: prev.emergencyContacts.map((c) =>
            c.id === contactId ? { ...c, customMessage } : c
          ),
        }));
      },
    }),
    [update]
  );

  const privacyActions = useMemo(
    () => ({
      async clearAllLocationData() {
        await removeKey(LOCATION_HISTORY_KEY);
        await removeKey(ALERT_LOG_KEY);
      },
    }),
    []
  );

  const gestureHelpers = useMemo(
    () => ({
      setShakeSensitivity(v: number) {
        update((prev) => ({
          ...prev,
          gesture: { ...prev.gesture, shakeSensitivity: clamp(v, 0.5, 3.0) },
        }));
      },
    }),
    [update]
  );

  return {
    loading,
    settings,
    update,
    contacts,
    contactActions,
    privacyActions,
    gestureHelpers,
  };
}
