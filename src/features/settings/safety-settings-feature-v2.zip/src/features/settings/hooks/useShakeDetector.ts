import { useEffect, useMemo, useRef, useState } from "react";

/**
 * Real-time shake detection (Expo-friendly if expo-sensors is installed).
 * If expo-sensors isn't available, the hook gracefully disables itself.
 */
type ShakeState = {
  available: boolean;
  active: boolean;
  lastShakeAt?: number;
  error?: string;
};

type Options = {
  enabled: boolean;
  sensitivity: number; // 0.5..3.0 (higher => easier to trigger)
  onShake?: () => void;
  updateIntervalMs?: number;
};

function loadAccelerometer(): any | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("expo-sensors");
    const Accelerometer = mod?.Accelerometer;
    if (Accelerometer?.addListener) return Accelerometer;
    return null;
  } catch {
    return null;
  }
}

function loadHaptics(): any | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("expo-haptics");
    return mod;
  } catch {
    return null;
  }
}

export function useShakeDetector(opts: Options): ShakeState {
  const Accelerometer = useMemo(() => loadAccelerometer(), []);
  const Haptics = useMemo(() => loadHaptics(), []);

  const [state, setState] = useState<ShakeState>({
    available: Boolean(Accelerometer),
    active: false,
  });

  const last = useRef({ x: 0, y: 0, z: 0, lastAt: 0, coolDownUntil: 0 });
  const subscriptionRef = useRef<any>(null);

  useEffect(() => {
    if (!Accelerometer) {
      setState((s) => ({ ...s, available: false, active: false, error: "Accelerometer not available" }));
      return;
    }

    const enabled = Boolean(opts.enabled);
    if (!enabled) {
      if (subscriptionRef.current) {
        subscriptionRef.current.remove?.();
        subscriptionRef.current = null;
      }
      setState((s) => ({ ...s, active: false }));
      return;
    }

    const interval = Math.max(50, Math.min(500, opts.updateIntervalMs ?? 100));
    try {
      Accelerometer.setUpdateInterval?.(interval);
    } catch {
      // ignore
    }

    const threshold = 2.6 - Math.max(0.5, Math.min(3.0, opts.sensitivity)) * 0.55;
    // threshold roughly 0.95..2.33; lower threshold => easier to trigger

    subscriptionRef.current?.remove?.();
    subscriptionRef.current = Accelerometer.addListener((data: { x: number; y: number; z: number }) => {
      const now = Date.now();
      if (now < last.current.coolDownUntil) return;

      const dx = Math.abs(data.x - last.current.x);
      const dy = Math.abs(data.y - last.current.y);
      const dz = Math.abs(data.z - last.current.z);

      last.current = { ...last.current, x: data.x, y: data.y, z: data.z, lastAt: now };

      const delta = dx + dy + dz;
      if (delta > threshold) {
        last.current.coolDownUntil = now + 1000; // 1s cooldown
        setState((s) => ({ ...s, lastShakeAt: now }));
        try {
          Haptics?.impactAsync?.(Haptics.ImpactFeedbackStyle?.Medium);
        } catch {
          // ignore
        }
        opts.onShake?.();
      }
    });

    setState((s) => ({ ...s, active: true, error: undefined }));

    return () => {
      subscriptionRef.current?.remove?.();
      subscriptionRef.current = null;
      setState((s) => ({ ...s, active: false }));
    };
  }, [Accelerometer, Haptics, opts.enabled, opts.onShake, opts.sensitivity, opts.updateIntervalMs]);

  return state;
}
