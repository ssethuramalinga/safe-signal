# Safety App — Settings Feature Module

Drop this folder into your project:

```
src/features/settings
```

Then import the screen:

```ts
import { SettingsScreen } from "./src/features/settings";
```

## Optional dependencies (feature unlocks)

This module is **dependency-tolerant** (it compiles even if these are missing), but adding them enables full functionality:

- `@react-native-async-storage/async-storage` — persistent settings storage
- `expo-sensors` — accelerometer shake detection
- `expo-haptics` — haptic feedback on shake detection
- `expo-sms` — send test SMS from inside the app (fallback uses `sms:` link)
- `expo-contacts` — pick emergency contacts from the phone address book
- `expo-speech` — voice preview for combinations (placeholder for ElevenLabs)
- `@react-native-community/slider` — nicer sliders for volume/sensitivity (fallback uses steppers)
- `expo-file-system` + `expo-sharing` — export data as JSON file

## Wiring into your app

Add `SettingsScreen` to your navigator / routing.

This module does **not** assume React Navigation — it’s just a screen component.


---

## Wire it into your app (matches your App.tsx)

Your `App.tsx` already wraps everything in a `NavigationContainer` and renders `RootNavigator`. Keep that as-is.

### Option A: Add as a Bottom Tab (recommended)

In your `src/navigation/RootNavigator.tsx` (or wherever you define your tab navigator), import:

```tsx
import { SettingsScreen, SETTINGS_ROUTE_NAME, settingsTabOptions } from "../features/settings";
```

Then add the tab:

```tsx
<Tab.Screen
  name={SETTINGS_ROUTE_NAME}
  component={SettingsScreen}
  options={settingsTabOptions}
/>
```

### Option B: Add as a Stack Screen

```tsx
import { SettingsScreen, SETTINGS_ROUTE_NAME, settingsStackOptions } from "../features/settings";

<Stack.Screen
  name={SETTINGS_ROUTE_NAME}
  component={SettingsScreen}
  options={settingsStackOptions}
/>
```

### Notes

- No extra packages are *required* for this module to run.
- If you install optional Expo packages (Contacts, Sensors, Haptics, SMS, Speech, etc.), the Settings page will automatically enable the advanced features.


Your `App.tsx` already wraps everything in a `NavigationContainer` and renders `RootNavigator`. Keep that as-is.

### Option A: Add as a Bottom Tab (recommended)

In your `src/navigation/RootNavigator.tsx` (or wherever you define your tab navigator), import:

```tsx
import { SettingsScreen, SETTINGS_ROUTE_NAME, settingsTabOptions } from "../features/settings";
```

Then add the tab:

```tsx
<Tab.Screen
  name={SETTINGS_ROUTE_NAME}
  component={SettingsScreen}
  options={settingsTabOptions}
/>
```

### Option B: Add as a Stack Screen

```tsx
import { SettingsScreen, SETTINGS_ROUTE_NAME, settingsStackOptions } from "../features/settings";

<Stack.Screen name={SETTINGS_ROUTE_NAME} component={SettingsScreen} options={settingsStackOptions} />
```

### Notes
- No extra packages are *required* for this module to run.
- If you install optional Expo packages (Contacts, Sensors, Haptics, SMS, Speech), the Settings page will automatically enable the advanced features.
